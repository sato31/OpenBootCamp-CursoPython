# Modifica la variable del anterior ejercicio en la consola de python
# y después muestrala por consola para ver la modificación de la variable.

helloWorld = "Hola Mundo!"
print(helloWorld)
# "Hola Mundo!"
helloWorld = "Soy un Hola Mundo Modificado"
print(helloWorld)
# "Soy un Hola Mundo Modificado"